Punk Kid font by Chris Hansen.

Www.geocities.com/Crizcrack666